## `atob`, `btoa`

[https://developer.mozilla.org/zh-CN/docs/Web/API/WindowBase64/btoa#polyfill](https://developer.mozilla.org/zh-CN/docs/Web/API/WindowBase64/btoa#polyfill)
