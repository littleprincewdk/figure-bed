### Unicode问题

[https://developer.mozilla.org/zh-CN/docs/Web/API/WindowBase64/Base64_encoding_and_decoding#solution_1_–_javascripts_utf-16_\>_base64](https://developer.mozilla.org/zh-CN/docs/Web/API/WindowBase64/Base64_encoding_and_decoding#solution_1_%E2%80%93_javascripts_utf-16_%3E_base64)
