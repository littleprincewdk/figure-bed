## `encodeURIComponent`, `decodeURIComponent`, `encodeURI`, `decodeURI`

将url中的特殊字符进行16进制编码。`% + 码点`