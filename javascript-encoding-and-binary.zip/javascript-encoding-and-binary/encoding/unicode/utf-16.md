## UTF-16

2-4位变长

JavaScript中字符串编码就是UTF-16