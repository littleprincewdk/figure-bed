## `charCodeAt`, `codePointAt`

`charCodeAt`: 返回 0 到 65535 之间的整数，表示给定索引处的 **UTF-16** 代码单元。如果`index`超出范围，返回 `NaN`。
`codePointAt`: 返回 一个 **Unicode** 编码点值的非负整数

### 问题：遍历字符串

```javascript
let s = '𠮷a';
for (let ch of s) {
  console.log(ch.codePointAt(0).toString(16));
}
// 20bb7
// 61
```
```javascript
// 或Array.from
let arr = [...'𠮷a']; // arr.length === 2
arr.forEach(
  ch => console.log(ch.codePointAt(0).toString(16))
);
// 20bb7
// 61
```
