## [Unicode](https://home.unicode.org/)

provide a unique code for every character, in every language, in every program, on every platform
为每个字符提供一个唯一的码点，不论什么语言，什么项目，什么平台

unicode规定了码点的对应关系，但如何存储不限制
