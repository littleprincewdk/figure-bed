## UTF-32

固定长度32位，和Unicode一一对应
