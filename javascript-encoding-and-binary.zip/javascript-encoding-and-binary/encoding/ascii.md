## ASCII

American Standard Code for Information Interchange，美国信息交换标准代码

![](./../assets/ascii.png)