### `Blob` `File`

表示一个不可变、原始数据的类文件对象

### API
`Blob.stream()`

`Blob.text()`

`Blob.arrayBuffer()`
