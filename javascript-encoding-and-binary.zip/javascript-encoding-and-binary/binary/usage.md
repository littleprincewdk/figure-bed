## 应用

web中接收`ArrayBuffer`
```javascript
const xhr = new XMLHttpRequest();
xhr.open("GET", "/foo.png", true);
xhr.responseType = "arraybuffer";
xhr.onload = function (e) {
  const arrayBuffer = xhr.response;
  // do something
};

xhr.send(null);
```

小程序中接收`ArrayBuffer`
```javascript
wx.request({
  url: 'www.foo.com',
  responseType: 'arraybuffer',
});
```

小程序中上传`ArrayBuffer`
```javascript
const fs = wx.getFileSystemManager();

fs.readFile({
  filePath: 'foo.png',
  success(data) {
    wx.request({
      url: 'www.foo.com',
      data: data.slice(0, 1024 * 512),
    });
  },
});
```
