## `ArrayBuffer`，`TypedArray`, `DataView`

`ArrayBuffer` 表示通用的、固定长度的原始二进制数据缓冲区
