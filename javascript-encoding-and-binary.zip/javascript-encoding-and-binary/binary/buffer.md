
## [`Buffer`](https://nodejs.org/api/buffer.html)

`Uint8Array`的子类

### API

`Buffer.from()`

`Buffer.concat()`
