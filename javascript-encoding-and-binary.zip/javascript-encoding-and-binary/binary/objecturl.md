## `URL.createObjectURL(object)`

`object`: 用于创建 URL 的 File 对象、Blob 对象或者 MediaSource 对象。

### 应用

1. 上传前预览本地图片
2. 流媒体

   B站，youtobe