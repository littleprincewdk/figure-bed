## 实例

### [小程序大文件分段上传](https://github.com/littleprincewdk/miniprogram-ali-oss/blob/5a5eedb2c82ec2de85b8156db56920a5d0190b0b/lib/multipart.js#L67)

```javascript
/**
 * Upload a part in a multipart upload transaction
 * @param {String} name the object name
 * @param {String} uploadId the upload id
 * @param {Integer} partNo the part number
 * @param {File} file upload File, whole File
 * @param {Integer} start  part start bytes  e.g: 102400
 * @param {Integer} end  part end bytes  e.g: 204800
 * @param {Object} options
 */
export async function uploadPart(name, uploadId, partNo, file, start, end, options = {}) {
  if (!is.arrayBuffer(file)) {
    if (!options.mime) {
      options.mime = mime.getType(path.extname(file));
    }
    file = await new Promise((resolve, rejcet) => {
      fs.readFile({
        filePath: file,
        success: (res) => resolve(res.data),
        fail: rejcet,
      });
    });
  }

  const data = file.slice(start, end);

  return this._uploadPart(name, uploadId, partNo, data, options);
}
```
### 对唱歌词解密

```javascript
const ENCRYPT_KEY = [63, 91, 97, 119, 94, 52, 39, 71, 86, 54, 49, 45, 02, 210, 110, 105];

export function decryptAndUnzip(xrc: ArrayBuffer): string {
  // decrypt
  const bytes = new Uint8Array(xrc);
  const bytesLength = bytes.length;
  const encryptKeyLength = ENCRYPT_KEY.length;
  for (let i = 0; i < bytesLength; i += 1) {
    // eslint-disable-next-line no-bitwise
    bytes[i] ^= ENCRYPT_KEY[i % encryptKeyLength];
  }

  // unzip
  return pako.inflate(bytes, { to: 'string' });
}
```

### 前端日志解析