## `Base64`, `ArrayBuffer`, `Blob`, `Buffer`, `Unicode`等之间的转换

https://github.com/dankogai/js-base64

https://stackoverflow.com/questions/21797299/convert-base64-string-to-arraybuffer

等等