- [前情提要](preface/index)


- 编码

  - [Base64](encoding/base64/index)
    - [`atob`, `btoa`](encoding/base64/atobtoa)
    - [Unicode问题](encoding/base64/unicode)
    - [应用](encoding/base64/usage)
  - [`encodeURI`家族](encoding/encodeURI)
  - [ASCII](encoding/ascii)
  - [Unicode](encoding/unicode/index)
    - [UTF-32](encoding/unicode/utf-32)
    - [UTF-16](encoding/unicode/utf-16)
    - [UTF-8](encoding/unicode/utf-8)
    - [`charCodeAt`, `codePointAt`](encoding/unicode/charCode)

- 二进制

  - [`Number.property.toString(radix)`](binary/number-tostring)
  - [`ArrayBuffer`](binary/arraybuffer)
  - [`Blob`](binary/blob)
  - [`Buffer`](binary/buffer)
  - [`createObjectURL`](binary/objecturl)
  - [应用](binary/usage)

- [转换](transform/index)

- [实例](instance/index)