## 如何浏览

```bash
$ npm i

$ npm start
```

然后打开网址
